# live-code-week-1

RULES:
------
1. Kerjakan secara individu. Semua bentuk diskusi tidak diperbolehkan dan menyebabkan skor live code ini 0.
2. Clone repo ‘live-code-week-1’ pada organization zen-fox-2018. Buatlah branch dengan nama kalian
3. Kerjakan pada file javascript yang telah disediakan
4. Membuka referensi eksternal seperti Google, StackOverflow, dan MDN diperbolehkan.
5. Pada text editor hanya ada folder ‘live-code-week-1‘
6. Dilarang membuka **repositori di organisasi tugas, baik pada organisasi batch sendiri ataupun batch lain, baik branch sendiri maupun branch orang lain (setelah melakukan clone, close tab github pada web browser kalian). Lakukan git add, git commit, git push dan pull request pada saat diperintahkan**
7. Tuliskan nama lengkap kalian saat melakukan pull request
